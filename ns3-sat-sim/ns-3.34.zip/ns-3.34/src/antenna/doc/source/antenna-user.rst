.. include:: replace.txt


++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  User Documentation
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

The antenna modeled can be used with all the wireless technologies and
physical layer models that support it. Currently, this includes
the physical layer models based on the SpectrumPhy. Please refer to
the documentation of each of these models for details.





