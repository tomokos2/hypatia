.. include:: replace.txt


#####################################################
References
#####################################################

.. [turkmani] Turkmani A.M.D., J.D. Parson and D.G. Lewis, "Radio propagation into buildings at 441, 900 and 1400 MHz",
   in Proc. of 4th Int. Conference on Land Mobile Radio, 1987.

